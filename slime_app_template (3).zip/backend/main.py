from fastapi import FastAPI, File, UploadFile
from fastapi.responses import FileResponse
from PIL import Image
import numpy as np
import os

app = FastAPI()
UPLOAD_DIR = "uploads"
RESULT_PATH = "result.png"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.post("/upload")
async def upload_image(file: UploadFile = File(...)):
    file_path = os.path.join(UPLOAD_DIR, file.filename)
    with open(file_path, "wb") as f:
        f.write(await file.read())

    img = Image.open(file_path).convert("RGBA")
    arr = np.array(img)
    arr[:, :, 0] = 255  # R成分だけ強調
    result_img = Image.fromarray(arr)
    result_img.save(RESULT_PATH)

    return FileResponse(RESULT_PATH, media_type="image/png")
